<?php
/*
Plugin Name: Fbm Page Blurb
Plugin URI:  http://URI_Of_Page_Describing_Plugin_and_Updates
Description: This plugin helps to add custom title, excerpt and featured image which can be used as a page blurb.
Version:     1.0
Author:      Vaishali Jitesh
Author URI:  http://URI_Of_The_Plugin_Author
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain: my-toolset
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

/**
 * Add meta fields (alternate title, excerpt, featured image) to meta box 
*/
function fbm_meta_box_markup($object)
{
    wp_nonce_field(basename(__FILE__), "fbm-meta-box-nonce");
	// Meta fields for page blurb on Edit Page view in Dashboard.
	?>
        <div>
		<!--Page Blurb Title-->
            <label for="fbm-meta-box-title">Alternate Title</label>
            <input name="fbm-meta-box-title" type="text" value="<?php echo get_post_meta($object->ID, "fbm-meta-box-title", true); ?>">

            <br/>
		<!--Page Blurb Excerpt-->
			 <label for="fbm-meta-box-excerpt">Alternate Excerpt</label>
			 <input name="fbm-meta-box-excerpt" type="text" value="<?php echo get_post_meta($object->ID, "fbm-meta-box-excerpt", true); ?>">
		</div>
					 
		<!--Page Blurb Featured Image-->
	<?php
	global $content_width, $_wp_additional_image_sizes;
	$image_id = get_post_meta( $object->ID, '_listing_image_id', true );
	$old_content_width = $content_width;
	$content_width = 254;

	if ( $image_id && get_post( $image_id ) ) {
		
		if ( ! isset( $_wp_additional_image_sizes['post-thumbnail'] ) ) {
		
			$thumbnail_html = wp_get_attachment_image( $image_id, array( $content_width, $content_width ) );
		} else {
			$thumbnail_html = wp_get_attachment_image( $image_id, 'post-thumbnail' );
		
		}
		if ( ! empty( $thumbnail_html ) ) {
			$content = '<div id="page_blurb_image">'.$thumbnail_html;
			$content .= '<p class="hide-if-no-js "><a href="javascript:;" id="remove_listing_image_button" >' . esc_html__( 'Remove listing image', 'text-domain' ) . '</a></p></div>';
			$content .= '<input type="hidden" id="upload_listing_image" name="_listing_cover_image" value="' . esc_attr( $image_id ) . '" />';
			
		}
		$content_width = $old_content_width;
	} else {
		$content = '<div id="page_blurb_image"><img src="" style="width:' . esc_attr( $content_width ) . 'px;height:auto;border:0;display:none;" />';
		$content .= '<p class="hide-if-no-js"><a title="' . esc_attr__( 'Set listing image', 'text-domain' ) . '" href="javascript:;" id="upload_listing_image_button" id="set-listing-image" data-uploader_title="' . esc_attr__( 'Choose an image', 'text-domain' ) . '" data-uploader_button_text="' . esc_attr__( 'Set listing image', 'text-domain' ) . '">' . esc_html__( 'Set listing image', 'text-domain' ) . '</a></p></div>';
		$content .= '<input type="hidden" id="upload_listing_image" name="_listing_cover_image" value="" />';
		
	}
	
echo $content;

}

/**
 * Add meta box to add/edit page in WordPress dashboard
*/
function add_fbm_meta_box()
{
    add_meta_box("demo-fbm-meta-box", "Custom Page Blurb", "fbm_meta_box_markup", "page", "side", "high", null);
}

add_action("add_meta_boxes", "add_fbm_meta_box");

/**
 * Save custom fields in the database
*/
function save_fbm_meta_box($post_id, $post, $update)
{
    if (!isset($_POST["fbm-meta-box-nonce"]) || !wp_verify_nonce($_POST["fbm-meta-box-nonce"], basename(__FILE__)))
        return $post_id;

    if(!current_user_can("edit_post", $post_id))
        return $post_id;

    if(defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
        return $post_id;

    $slug = "page";
    if($slug != $post->post_type)
        return $post_id;
		
    $meta_box_title_value = "";
    $meta_box_excerpt_value = "";
    $meta_box_image_value = "";
	
    if(isset($_POST["fbm-meta-box-title"]))
    {
		$meta_box_title_value = $_POST["fbm-meta-box-title"];
	}   
    update_post_meta($post_id, "fbm-meta-box-title", $meta_box_title_value);

    if(isset($_POST["fbm-meta-box-excerpt"]))
    {
        $meta_box_excerpt_value = $_POST["fbm-meta-box-excerpt"];
    }   
    update_post_meta($post_id, "fbm-meta-box-excerpt", $meta_box_excerpt_value);
	if( isset( $_POST['_listing_cover_image'] ) ) {
		$image_id = (int) $_POST['_listing_cover_image'];
		update_post_meta( $post_id, '_listing_image_id', $image_id );
	}
}
add_action("save_post", "save_fbm_meta_box", 10, 3);


/**
 * Display page or sub-pages blurb shorcode
*/
add_shortcode( 'display-pages-blurb', 'fbm_display_page_blurb_shortcode' );
function fbm_display_page_blurb_shortcode( $atts ) {

	//Prepare query parameters
	$args = array(
		'numberposts' => 1,
		'order' => 'ASC',
		'post_type' => 'page',
		'post_status' => 'publish'	,
	);
	// Pull in shortcode attributes and set defaults
	$atts = shortcode_atts( array(	'id'  => false), $atts, 'display-pages-blurb' );
	
	// If the post id is provided, fetch the pages with IDs provided
	if($atts['id']!=0 ){
		$args['post__in']= array($atts['id']);
	}
		// If the post id is not provided, fetch the child pages of the current page
	else{
		$args['post_parent__in'] = array(get_the_ID());
	}
	$get_blurb_data = new get_page_blurb_data();
	$blurb_output= $get_blurb_data->get_page_blurb($args);
	return $blurb_output;
}
	
// This class executes the query based on arguments, fetches results and returns blurb meta data to be printed in HTML format.	
class get_page_blurb_data {
	function get_page_blurb($args){
		$blurb_pages = new WP_Query($args);
		$return_str="<ul class='fbm_page_blurb'>";
		while( $blurb_pages->have_posts() ): $blurb_pages->the_post();
				$return_str.= 	"<li class='fbm_page_meta_title'>".get_post_meta(get_the_ID(), 'fbm-meta-box-title', true)."</li>";
				$return_str.= 	"<li class='fbm_page_meta_excerpt'>".get_post_meta(get_the_ID(), 'fbm-meta-box-excerpt', true)."<li>";
		 		$return_str.="<li class='fbm_page_meta_thumb'>".wp_get_attachment_image( get_post_meta(get_the_ID(), '_listing_image_id', true), 'thumbnail' )."<li>";
		endwhile;
		$return_str.="</ul>";
		wp_reset_postdata();
		return $return_str;
	}
}

function fbm_page_blurb_enqueue_scripts( $hook ) {	
	wp_enqueue_script( 'blurb_upload_script', plugin_dir_url( __FILE__) . 'js/blurb-upload.js' ,false, null, true );
}
add_action( 'admin_enqueue_scripts', 'fbm_page_blurb_enqueue_scripts' );

function fbm_page_blurb_enqueue_stylesheet() 
{
	wp_enqueue_style( 'blurb_style', plugins_url( '/css/blurb_style.css', __FILE__ ) );
}

add_action('wp_enqueue_scripts', 'fbm_page_blurb_enqueue_stylesheet');
add_action('admin_enqueue_scripts', 'fbm_page_blurb_enqueue_stylesheet');